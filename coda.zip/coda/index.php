<?php
error_reporting(E_ALL);
// Create connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname="coda";
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
include 'vendor/autoload.php';
include 'vendor/codelicious/php-coda-parser/src/Parser.php';

use Codelicious\Coda\Parser;

$parser = new Parser();
$statements = $parser->parseFile('coda-file.cod');


if(isset($_POST['btn-upload']))
{

    $file = rand(1000,100000)."-".$_FILES['file']['name'];
   $file_loc = $_FILES['file']['tmp_name'];
    $file_size = $_FILES['file']['size'];
    $file_type = $_FILES['file']['type'];

    $folder="upload/";

if(isset($_FILES['file']['name'])){
move_uploaded_file($file_loc,$folder.$file);
}
    $folder="upload/";
    echo '<pre>';
  // print_r($statements);
    echo '</pre>';

    foreach ($statements as $statement) {
      $c_date=$statement->getDate()->format('Y-m-d') ;
   foreach ($statement->getTransactions() as $transaction) {
        $transaction->getAccount()->getName() . ": " . $transaction->getAmount() . "\n";
       $name=$transaction->getAccount()->getName();
      $amount=$transaction->getAmount();
        $bic=$transaction->getAccount()->getBic();
       $mobile=$transaction->getAccount()->getNumber();
       $currency=$transaction->getAccount()->getCurrency();
       // echo $cdate=$transaction->getDate()->format('Y-m-d') . "\n";
     // echo $message=$transaction->getAccount()->getCountryCode();
       //$timezone= $transaction->getAccount()->getTimezone();
     //  $timezonetype= $transaction->getTimezoneType();
       $timezone='';
       $timezonetype='';
       $transaction_detail='';
       $comp_id_no='';
       $country='';
       $uploaded_at=date('Y-m-d' );
       echo $initial_balance= $statement->getInitialBalance() ;
       echo $new_balance=$statement->getNewBalance();
       echo   $info_msg= $statement->getInformationalMessage() . "\n";
      // echo $message=$statement->getDirectDebit();
        $sql="INSERT INTO coda_data(c_date,name,bic,mobile_no,currency_code,amount,initial_balance,new_balance,uploaded_at) VALUES('".$c_date."','".$name."','".$bic."','".$mobile."','".$currency."','".$amount."','".$initial_balance."','".$new_balance."','".$uploaded_at."')";
 mysqli_query($conn,$sql);


   }



    }


}
?>
<!DOCTYPE html>
<html>
<title>

</title>
<head>
    <link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css"/>

    <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.11.1/js/jquery.dataTables.min.js"></script>

    <script type="text/javascript" src="DataTables/datatables.min.js"></script>
    <script>
          $(document).ready(function() {
            $('#example').DataTable();
        } );
    </script>

</head>
<body>

<form action="" method="post" enctype="multipart/form-data">
    <input type="file" name="file" />
    <button type="submit" name="btn-upload">upload</button>
</form>
<table id="example" class="display" style="width:100%">
    <thead>
    <tr>
        <th>Name</th>
        <th>Bic</th>
        <th>Currency</th>
        <th>Amount</th>
        <th>Initial Balance</th>
        <th>New Balance</th>
        <th>Upload Date</th>
    </tr>
    </thead>
    <tbody>
   <?php
    $sql1="select * from coda_data";
    $result=mysqli_query($conn,$sql1);
    $num=mysqli_num_rows($result);
    if($num>0){
   while($row = mysqli_fetch_array($result))
    {
    ?>

    <tr>
        <td><?php echo $row['name'];?></td>
        <td><?php echo $row['bic'];?></td>
        <td><?php echo $row['currency_code'];?></td>
        <td><?php echo $row['amount'];?></td>
        <td><?php echo $row['initial_balance'];?></td>
        <td><?php echo $row['new_balance'];?></td>
        <td><?php echo $row['uploaded_at'];?></td>
    </tr>
    <?php
   }
    }
    ?>

    </tbody>
</table>

</body>
</html>


